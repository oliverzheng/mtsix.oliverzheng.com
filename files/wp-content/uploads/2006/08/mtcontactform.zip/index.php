<?
	// Define your email address (who to send the email to), and the subject of the email
	define("MYEMAIL", "olivereatsolives@gmail.com");
	define("SUBJECT", "Message from Test Contact Form (mtsix.com)");
	
	// Include the ajax engine
	require("sajax.php");
	
	// Define our email function
	function send_email($sender_name, $sender_email, $sender_website, $email_message, $email_cc) {
		// Check to see if the fields are empty. If empty, email will not be sent
		if(!empty($sender_name) && !empty($sender_email) && !empty($email_message)) {
		
			$email_message .= "\r\n";
			
			// Append sender's email to the message, if it exists
			if (!empty($email_website)) {
				$email_message .= "\r\nSender's Website: ".$email_website;
			}
			
			// Append sender's IP
			$email_message .= "\r\nSender's IP: ".$_SERVER['REMOTE_ADDR'];
			
			// Break lines
			$email_message = str_replace("\r\n", "<br />", $email_message);
			$email_message = str_replace("\r", "<br />", $email_message);
			$email_message = str_replace("\n", "<br />", $email_message);
			
			$headers  = "MIME-Version: 1.0\r\n";
			$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
			$headers .= "From: ".$sender_name." <".$sender_email.">\r\n";
			
			if(mail(MYEMAIL, SUBJECT, $email_message, $headers)) {
				if($email_cc == 'false' || mail($sender_email, SUBJECT, $email_message, $headers)) {
				}
				return "emailsent";
				exit();

			} else {
				return "emailerror";
			}
		} else {
			return "emailempty";
		}
	}


	sajax_init();
	// $sajax_debug_mode = 1;
	sajax_export("send_email");
	sajax_handle_client_request();
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Contact Form</title>
<style type="text/css" media="screen">
<!--
html {
	height: 100%;
	background: #FFFFFF;
	text-align: center;
}
body {
	font: 13px/1.5em Verdana, Arial, Helvetica, sans-serif;
	margin: 0 auto;
	width: 438px;
	text-align: left;
	text-align: center;
}
h1 {
	margin: 30px 0;
	padding: 0px 0px 10px 20px;
	font-size: 24px;
	color: #666666;
	border-bottom: 1px solid #CCCCCC;
	font-family: Geneva, Arial, Helvetica, sans-serif;
	text-align: left;
}
#mt_contact_form {
	border: 1px solid #DDDDDD;
	background: #FAFAFA;
	padding: 10px 15px 5px 15px;
	margin: 0 auto 10px auto;
	text-align: left;
	width: 408px;
}
#mt_contact_form ul#mt_contact_form_ul {
	margin: 0;
	padding: 0;
	list-style: none;
	width: 408px;
}
#mt_contact_form ul#mt_contact_form_ul li {
	margin: 0 0 10px;
	padding: 0;
	list-style: none;
}
#mt_contact_form label.mt_contact_form_label {
	display: block;
	padding-bottom: 4px;
}
#mt_contact_form input.mt_contact_form_text {
	width: 240px;
	height: 17px;
	padding: 3px;
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 13px;
	margin: 0;
}
#mt_contact_form textarea.mt_contact_form_textarea {
	width: 400px;
	height: 170px;
	margin: 0px;
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 13px;
	padding: 2px 3px;
	line-height: 1.5em;
	overflow: auto;
}
#mt_contact_form input.mt_contact_form_checkbox {
	position: relative;
	margin-top: 0px;
	margin-bottom: 0;
	top: -1px;
}
* html #mt_contact_form input.mt_contact_form_checkbox {
	top: 1px;
}
#mt_contact_form li#mt_contact_form_indicator {
	float: right;
	text-align: right;
	position: relative;
	top: 2px;
	margin: 0;
	padding: 0;
	line-height: 1em;
	height: 16px;
}
#mt_contact_form #mt_contact_form_indicator span {
	padding-right: 20px;
	position: relative;
	top: 1px;
}
* html #mt_contact_form #mt_contact_form_indicator span {
	top: 2px;
}
#mt_contact_form .mt_contact_form_indicator_normal {
	visibility: hidden;
}
#mt_contact_form .mt_contact_form_indicator_loading {
	background: url("./images/indicator.gif") no-repeat top right;
	color: #FAFAFA;
}
* html #mt_contact_form .mt_contact_form_indicator_loading {
	background: 0;
	color: #000000;
}
#mt_contact_form .mt_contact_form_indicator_error {
	background: url("./images/error.png") no-repeat top right;
}
#mt_contact_form .mt_contact_form_indicator_success {
	background: url("./images/check.png") no-repeat top right;
}
#mt_contact_form .mt_contact_form_normal_border {
	border: 1px solid #CCCCCC;
}
#mt_contact_form .mt_contact_form_normal_border_error {
	border: 1px solid #7b0000;
}
#page_footer {
	text-align: center;
	padding-left: 20px;
	font-size: 10px;
	border-top: 1px solid #CCCCCC;
	padding-top: 10px;
	margin-top: 40px;
}
#page_footer p {
	margin: 0;
}
a {
	color: #000000;
	text-decoration: none;
	border-bottom: 1px solid #999999;
}
a:hover {
	border-bottom: 1px solid #333333;
}
-->
</style>
	<script>
	<?
	sajax_show_javascript();
	?>
	
	function send_email_cb(z) {
		if (z == 'emailsent') {
			document.getElementById("mt_contact_form_text").innerHTML = "Email Sent";
			document.getElementById("mt_contact_form_indicator").className = "mt_contact_form_indicator_success";
			document.getElementById("mt_contact_form_email_send").disabled = false;
		} else if (z == 'emailerror') {
			document.getElementById("mt_contact_form_text").innerHTML = "Error Sending Email";
			document.getElementById("mt_contact_form_indicator").className = "mt_contact_form_indicator_error";
			document.getElementById("mt_contact_form_email_send").disabled = false;
		}
	}
	function sendtheemail_styles() {
		document.getElementById("mt_contact_form_email_send").disabled = true;
		document.getElementById("mt_contact_form_text").innerHTML = "Please Wait";
		document.getElementById("mt_contact_form_indicator").className = "mt_contact_form_indicator_loading";
	}

	function sendtheemail() {
		var sender_name, sender_email, sender_message, alert_error;
		
		sender_name = document.getElementById("mt_contact_form_sender_name").value;
		sender_email = document.getElementById("mt_contact_form_sender_email").value;
		sender_website = document.getElementById("mt_contact_form_sender_website").value;
		email_message = document.getElementById("mt_contact_form_email_message").value;
		email_cc = document.getElementById("mt_contact_form_cc").checked;
		
		alert_error = "";
		
		if(sender_name.length < 1) {
			alert_error += "Please put in your name.\n";
		}
		if(sender_email.length < 1) {
			alert_error += "Please put in your email.\n";
		} else if (!checkemail(sender_email)) {
			alert_error += "Please enter a valid email address.\n";
		}
		if(email_message.length < 1) {
			alert_error += "Please enter a message.";
		}
		
		if(alert_error.length > 0) {
			alert(alert_error);
		} else {
			x_send_email(sender_name, sender_email, sender_website, email_message, email_cc, send_email_cb);
			sendtheemail_styles();
		}
	}
	function checkemail(str) {
		var at="@"
		var dot="."
		var lat=str.indexOf(at)
		var lstr=str.length
		var ldot=str.indexOf(dot)
		if (str.indexOf(at)==-1){
			return false;
		}
		if (str.indexOf(at)==-1 || str.indexOf(at)==0 || str.indexOf(at)==lstr){
			return false;
		}
		if (str.indexOf(dot)==-1 || str.indexOf(dot)==0 || str.indexOf(dot)==lstr){
			return false;
		}
		if (str.indexOf(at,(lat+1))!=-1){
			return false;
		}
		if (str.substring(lat-1,lat)==dot || str.substring(lat+1,lat+2)==dot){
			return false;
		}
		if (str.indexOf(dot,(lat+2))==-1){
			return false;
		}
		if (str.indexOf(" ")!=-1){
			return false;
		}
		return true;
	}
	</script>
</head>

<body>

<h1>MT Contact Form Demo</h1>

<div id="page">
<form id="mt_contact_form" action="<? echo $_SERVER["REQUEST_URI"]; ?>" method="POST">

	<ul id="mt_contact_form_ul">
		<li>
			<label class="mt_contact_form_label" for="mt_contact_form_sender_name">Name</label>
			<input type="text" name="mt_contact_form_sender_name" id="mt_contact_form_sender_name" class="mt_contact_form_normal_border mt_contact_form_text" tabindex="1" />
		</li>
		<li>
			<label class="mt_contact_form_label" for="mt_contact_form_sender_email">Email</label>
			<input type="text" name="mt_contact_form_sender_email" id="mt_contact_form_sender_email" class="mt_contact_form_normal_border mt_contact_form_text" tabindex="2" />
		</li>
		<li>
			<label class="mt_contact_form_label" for="mt_contact_form_sender_website">Website (optional)</label>
			<input type="text" name="mt_contact_form_sender_website" id="mt_contact_form_sender_website" class="mt_contact_form_normal_border mt_contact_form_text" tabindex="3" />
		</li>
		<li>
			<label class="mt_contact_form_label" for="mt_contact_form_email_message">Message</label>
			<textarea cols="20" rows="5" name="mt_contact_form_email_message" id="mt_contact_form_email_message" class="mt_contact_form_normal_border mt_contact_form_textarea" tabindex="4"></textarea>
		</li>
		<li>
			<label for="mt_contact_form_cc">
			<input type="checkbox" name="mt_contact_form_cc" id="mt_contact_form_cc" class="mt_contact_form_checkbox" tabindex="5" />
			CC this message to yourself.</label>
		</li>
		<li id="mt_contact_form_indicator" class="mt_contact_form_indicator_normal"><span id="mt_contact_form_text"></span></li>
		<li>
			<input type="submit" name="submit" value="Send Email" id="mt_contact_form_email_send" onclick="sendtheemail(); return false;" tabindex="6" />
		</li>
	</ul>
	
</form>

<div id="page_footer">
<p>Powered by MT Contact Form &#8212; Version 0.1a</p>
<p>&copy; Copyright <a href="http://mtsix.com/">Oliver Zheng</a> 2006.</p>
</div>
</div>
</body>
</html>
